--------------------------------------------------------------------------------------------------------------------
|                            Hi Team! Welcome to Cheap Flights Search                                               |
|- This website searchs for cheap flights by sending API request to 'https://developers.amadeus.com/self-service'.  |
|- After getting the response, the available flights will be displayed and sorted from lowest price to the highest. |
|- The controller was coded in Python and the Framework used to run the wbsite is Flask.                            |
--------------------------------------------------------------------------------------------------------------------

1. Application.py:
    - Before sending the API request, it has to authenticate with Amadeus.com by using API_KEY & API_SECRET
    - If the authentication passed, token will be sent from Amadeus.com to be used with the API request
    - The main route is index.html and in this page the user will be able to type the flight information then
        submit the form to search route in the controller.
    - Search function will use the information submitted to send it as API request  with the token to Amadeus.com
    - If there's no data received, Search function will direct the user to result.html by passing varialbe Status= False
        which will tell result.html to display image saying 'sorry no result found' and the user will get a button to go
        back to search again on the main page (index.com)
    - If there's data received, it will direct the uesr to the same page and passing variable Status=True which tells
        the page to display the result in rows
    - Function check() will be called when index.html send Ajax jQuery to route /check. Jquery function will be called
        inside index.html page while the user is typing in the name of the airport city in field From/To. Then check()
        will send sql query to database airport.db which has 2 column: Airport, Code. Finally check() will send back JSON
        response to index.html containing all the airport mathcing what the user is typing.
    - Function format_date(data) called inside the controller (application.py) to seperate the time and the date and to display
        time in 12-hour format.
    - Function dictionary(key, data) is called inside the controller to map the airline code with the airline name and aircraft name
        with the code- Amadeus sends the data with the codes for airports, airline and airplane also it send dictionary to map the code
        with the name.

2. layout.html:
    - contains the required links to import bootstrap4 CSS/JAVASCRIPTS
    - Also it imports datarangepicker.js library to enable the user to pick the dates istead of typing in.

3. Index.html:
    - The from is on the top of the background image
    - when the user either click on From or To, bootstrap modal will open to let the user search for the airport name by calling javascript
        function which send Ajax Jquery to check route
    - The form validate if the user filled out all the required information using the javascript.
    - when the user submit the form and waiting for the result, javascript function will be called to hid the form and display spinning wheel
        instead as an indication for the user that there is date is being processed.

4. result.html:
    - display the flights in rows and inside each row there's Details button when clicked it will collapse and div containing table showing the
        details for the trips both ways.
