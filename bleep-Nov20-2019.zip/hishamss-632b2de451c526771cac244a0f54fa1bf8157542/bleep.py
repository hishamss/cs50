from cs50 import get_string
from sys import argv
import sys
words = []


def main():

    if len(argv) != 2:
        print("Usage: python bleep.py dictionary")
        sys.exit(1)

    file = open(str(argv[1]), "r")
    for line in file:
        words.append(line.rstrip("\n"))

    file.close()

    message = get_string("What message would you like to censor?\n")

    message = message.split()
    for word in message:

        if (word.lower() in words) == True:

            print('*' * len(word), end=" ")
        else:
            print(word, end=" ")
    print()

if __name__ == "__main__":
    main()
