#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <crypt.h>
#include <unistd.h>
char *pass, *hash, *temp, *salt;
int search(int index);
int i, i1, i2, i3, i4;


int main(int argc, string argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./crack hash\n");
        return 1;
    }
    // Allocate memory for salt with length of 3  
    salt = malloc(3 * sizeof(char));
    salt[0] = argv[1][0];
    salt[1] = argv[1][1];
    
    hash = malloc((strlen(argv[1]) + 1) * sizeof(char));
    strcpy(hash, argv[1]);
    

//length 1:
//allocate memory with length 2 cause the last element is null
    pass = malloc(2 * sizeof(char));
    printf("Searching password with 1 digit.....\n");
// if search returned 1: the password matched , then jump to the end    
    if (search(0))
    {
        goto End;
    }
    
           
//length 2
    free(pass);
    pass = malloc(3 * sizeof(char));
    printf("Searching password with 2 digits.....\n");
    // if search returned 1: the password matched , then jump to the end
    i1 = 65;
    
    while (i1 < 123)
    {
        pass[0] = i1;
        
        if (search(1))
        {
            goto End;
        }
        if (i1 == 90) 
        {
            i1 = 96;
        }    
        
        i1++;
    }
    
    
        
            
//length 3
    free(pass);
    pass = malloc(4 * sizeof(char));
    printf("Searching password with 3 digits.....\n");
    // if search returned 1: the password matched , then jump to the end
    i1 = 65; 
    i2 = 65;
            
    while (i1 < 123)
    {
        pass[0] = i1;
        i2 = 65;
        while (i2 < 123)
        {
            pass[1] = i2;
            if (search(2))
            {
                goto End; 
            }
            if (i2 == 90) 
            {
                i2 = 96;
            }    
            i2++;
        }  
        if (i1 == 90) 
        {
            i1 = 96;
        }
        i1++;
    }
    
            
//length 4:
    free(pass);
    pass = malloc(5 * sizeof(char));
    printf("Searching password with 4 digits.....\n");
    // if search returned 1: the password matched , then jump to the end
    i1 = 65; 
    i2 = 65;
    i3 = 65;
            
    while (i1 < 123)
    {
        pass[0] = i1;
        i2 = 65;
        while (i2 < 123)
        {
            pass[1] = i2;
            i3 = 65;
            while (i3 < 123)
            {
                pass[2] = i3;
                if (search(3))
                {
                    goto End;
                }
                if (i3 == 90) 
                {
                    i3 = 96;
                }    
                i3++;
            }  
            if (i2 == 90) 
            {
                i2 = 96;
            }
            i2++;
        }
        if (i1 == 90) 
        {
            i1 = 96;
        }
        i1++;
    }     
    
        
//length 5
    free(pass);
    pass = malloc(6 * sizeof(char));
    printf("Searching password with 5 digits.....\n");
    i1 = 65; 
    i2 = 65;
    i3 = 65;
    i4 = 65;
            
    while (i1 < 123)
    {
        pass[0] = i1;
        i2 = 65;
        while (i2 < 123)
        {
            pass[1] = i2;
            i3 = 65;
            while (i3 < 123)
            {
                pass[2] = i3;
                i4 = 65;
                while (i4 < 123)
                {
                    pass[3] = i4;
                    if (search(4))
                    {
                        goto End;
                    }
                    if (i4 == 90) 
                    {
                        i4 = 96;
                    }    
                    i4++;
                }  
                if (i3 == 90) 
                {
                    i3 = 96;
                }
                i3++;
            }
            if (i2 == 90) 
            {
                i2 = 96;
            }
            i2++;
        }
        if (i1 == 90) 
        {
            i1 = 96;
        }
        i1++;  
    }
    
    printf("No match!!! \n");
    
End:
    free(salt);
    free(hash);
    free(pass);
    free(temp);
    return 0;
}
// this function will return 1 if the password matched else will return 0
int search(int index)
{
    
    i = 65;
    while (i < 123)
    {
        free(temp);
        temp = malloc(14 * sizeof(char));
        pass[index] = (char) i;
        strcpy(temp, crypt(pass, salt));
        
        if (!(strcmp(hash, temp)))
        {
            printf("password: %s\n", pass);
            return 1;
        }
        if (i == 90) 
        {
            i = 96;
        }
        i++;
    }
    return 0; 
}
