#include <cs50.h>
#include <math.h>
#include <stdio.h>
long number, value, res1, res2, res3, res4, divi, power;
int count, mult, quo, rem1, total, sum = 0, sum1 = 0, type;

int main(void)
{
start:
    count = 0;
    number = get_long("Number: ");
    divi = number;
    // start over if the number is equal or less than zero
    if (divi <= 0)
    {
        goto start;
    }
    // count the digits # for the entered value
    while (divi != 0)
    {
        divi = divi / 10;
        count ++; 
    }
    
  
    //  start over if # of digits is <13 or >16
    if (count < 13 || count > 16)
    {
        printf("INVALID\n");
        goto start;
        
    }
    count--;
    count--;
    power = pow(10, count);
    // remove the digits after the first 2 digits of the entered number 
    // to keep the first digits only for the card type
    type = number / power;
    value = number;
    while (value != 0)
    {

start1:
// store the last 2 digits of value into res1
        res1 = value % 100; 
// remove the last 2 digits from value
        value = value / 100; 
// store the first digit from right in res1 into res2
        res2 = res1 / 10;
        res4 = res1 % 10;    
        mult = res2 * 2;
// if mult is 2 digits (>=10) then split it to 2 digits
        if (mult >= 10)
        {
            rem1 = mult;
            quo = mult;
            rem1 = rem1 % 10;
            quo = quo / 10;
            sum = quo + rem1 + sum;
            sum1 = sum1 + res4;
            goto start1;
        }
        sum = mult + sum;
        sum1 = sum1 + res4;
    }
    total = sum + sum1;
    total = total % 10;
    if (total == 0)
    {
        if (type >= 40 && type <= 42) 
        {
            printf("VISA\n");
        }
        else if (type >= 51 & type <= 55)
        {
            printf("MASTERCARD\n");
        }
        else 
        {
            printf("AMEX\n");
        }
    }
    
    else 
    {
        printf("NOT VALID CARD\n");
    }
}
