#!/bin/bash
export API_KEY=pk_3c1fc90c9c0e4a53b2e667cde10cc848
