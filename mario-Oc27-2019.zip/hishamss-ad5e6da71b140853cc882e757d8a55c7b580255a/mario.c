#include <cs50.h>
#include <stdio.h>
int h;
int i;
int iii;
int ii=1;
int p;
int main(void)
{
    do {h = get_int("Height: ");}
    while (h< 1 || h> 8);
    
while(ii<=h){
    p=h-ii;
   while (p != 0)
   {
    printf(" ");
       p--;
   }
    
    for (i= 1; i<=ii; i++)
    { 
         printf("#");
        
    }
    printf("  ");
    for (iii= 1; iii<=ii; iii++)
    { 
        printf("#");
        
    }
    printf("\n");
    ii++;
    
}
}
