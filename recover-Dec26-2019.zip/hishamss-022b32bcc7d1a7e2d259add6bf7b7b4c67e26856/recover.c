#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>
#include <string.h>
// unsigned char = 1 byte (0-255)
unsigned char *buf;
char *fname;
int count = 0;
int main(int argc, char *argv[])
{

    if (argc != 2)
    {
        printf("Usage: ./recover image\n");
        return 1;
    }

    FILE *file = fopen(argv[1], "r");

    if (file == NULL)
    {
        printf("Failed to open\n");
        // returns 2 if the file not found
        return 2;
    }

    FILE *img = NULL;

    while (1)
    {
        buf = malloc(512);
        // read from raw file 1 bytes and 512 times then but the rsult in buf dynamic memory
        fread(buf, 1, 512, file);
        // fread will keep reading from card.raw till it comes across EOF then it will return 1
        if (feof(file))
        {
            break ;
        }

        // check if the pattern discovered (biginnning of jpg file)
        bool containsJpegHeader = (int) buf[0] == 255 && (int) buf[1] == 216 && (int) buf[2] == 255 && ((int) buf[3] & 240) == 224;

        if (containsJpegHeader && img != NULL)
        {
           fclose(img);
           count++;
        }

        if (containsJpegHeader)
        {
            fname = malloc(7);
            sprintf(fname, "%03i.jpg", count);
            img = fopen(fname, "w");
            free(fname);
        }

        if(img != NULL)
        {
            fwrite(buf, 1, 512, img);
        }

        free(buf);
    }

    fclose(file);

}
