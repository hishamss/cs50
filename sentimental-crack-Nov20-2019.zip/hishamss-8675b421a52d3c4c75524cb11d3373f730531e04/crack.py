import sys
import crypt
if len(sys.argv) != 2:
    sys.exit("Usage: python crack.py hash")
hash = str(sys.argv[1])
salt = hash[:2]
# length 1
finish = False
password = list('A')
for i in list(range(65, 91)) + list(range(97, 123)):
    password[0] = chr(i)
    if (crypt.crypt(("".join(password)), str(salt))) == hash:
        print("".join(password))
        finish = True
        break
# length2
if finish == False:
    password = list("AA")
    for i in list(range(65, 91)) + list(range(97, 123)):
        password[0] = chr(i)
        for i in list(range(65, 91)) + list(range(97, 123)):
            password[1] = chr(i)
            if (crypt.crypt(("".join(password)), str(salt))) == hash:
                print("".join(password))
                finish = True
                break
        else:
            continue
        break
# length3
if finish == False:
    password = list("AAA")
    for i in list(range(65, 91)) + list(range(97, 123)):
        password[0] = chr(i)
        for i in list(range(65, 91)) + list(range(97, 123)):
            password[1] = chr(i)
            for i in list(range(65, 91)) + list(range(97, 123)):
                password[2] = chr(i)
                if (crypt.crypt(("".join(password)), str(salt))) == hash:
                    print("".join(password))
                    finish = True
                    break
            else:
                continue
            break
        else:
            continue
        break
# length4
if finish == False:
    password = list("AAAA")
    for i in list(range(65, 91)) + list(range(97, 123)):
        password[0] = chr(i)
        for i in list(range(65, 91)) + list(range(97, 123)):
            password[1] = chr(i)
            for i in list(range(65, 91)) + list(range(97, 123)):
                password[2] = chr(i)
                for i in list(range(65, 91)) + list(range(97, 123)):
                    password[3] = chr(i)
                    if (crypt.crypt(("".join(password)), str(salt))) == hash:
                        print("".join(password))
                        finish = True
                        break
                else:
                    continue
                break
            else:
                continue
            break
        else:
            continue
        break
# length5
if finish == False:
    password = list("AAAAA")
    for i in list(range(65, 91)) + list(range(97, 123)):
        password[0] = chr(i)
        for i in list(range(65, 91)) + list(range(97, 123)):
            password[1] = chr(i)
            for i in list(range(65, 91)) + list(range(97, 123)):
                password[2] = chr(i)
                for i in list(range(65, 91)) + list(range(97, 123)):
                    password[3] = chr(i)
                    for i in list(range(65, 91)) + list(range(97, 123)):
                        password[4] = chr(i)
                        print("".join(password))
                        if (crypt.crypt(("".join(password)), str(salt))) == hash:
                            print("".join(password))
                            finish = True
                            break
                    else:
                        continue
                    break
                else:
                    continue
                break
            else:
                continue
            break
        else:
            continue
        break