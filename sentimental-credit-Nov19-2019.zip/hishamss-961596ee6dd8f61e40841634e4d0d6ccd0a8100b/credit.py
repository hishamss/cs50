from cs50 import get_int

check = False

while True:
    # take input from user
    number = get_int("Number: ")
    # check if the input is a number
    if isinstance(number, int):
        # check if the digits from 13 to 16 digits
        if len(str(number)) >= 13 and len(str(number)) <= 16:
            check = True
            break

        break
if check:
    # convert number to list (like array in c)
    res = [int(x) for x in str(number)]
    length = len(res)
    sum = 0
    total = 0
    # iterate over res but skip the last digit
    for i in range(length - 1):
        # if the length of number is even then take the digits of even indexes
        if (i % 2) == 0 and (length % 2) == 0:
            product = 2 * res[i]
            total += res[i+1]
            if product >= 10:
                product = str(product)
                sum += int(product[:1])
                sum += int(product[1:2])

            else:
                sum += int(product)
        # if the length of number is odd then take the digits of odd indexes
        elif (i % 2) != 0 and (length % 2) != 0:
            product = 2 * res[i]
            total += res[i-1]
            if product >= 10:
                product = str(product)
                sum += int(product[:1])
                sum += int(product[1:2])

            else:
                sum += int(product)

    if (length % 2) != 0:
        total += res[length - 1] + sum

    else:
        total += sum
    total = [int(x) for x in str(total)]
    if (total[len(total) - 1]) == 0:

        type = int(str(number)[:2])

        if type == 34 or type == 37:
            print("AMEX")

        elif type >= 51 and type <= 55:
            print("MASTERCARD")

        elif int(str(number)[:1]) == 4:
            print("VISA")

    else:
        print("INVALID")

else:
    print("INVALID")