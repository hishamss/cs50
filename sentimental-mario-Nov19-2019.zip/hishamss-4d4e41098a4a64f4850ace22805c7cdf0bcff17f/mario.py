from cs50 import get_int

while True:
    h = get_int("Height: ")
    # check if the input is integer
    if isinstance(h, int):
        # check if the integer between 1 and 8
        if h >= 1 and h <= 8:
            break
count = 1
for i in range(h):

    space = h - count
    # prints the white space before
    for index in range(space):

        print(" ", end="")
    # prints the left half of the payramid
    for index in range(i+1):

        print("#", end="")
    # prints the gab between the 2 halfs
    print("  ", end="")
    # prints the right half of the pyramid
    for index in range(i+1):

        print("#", end="")
    # new line
    print()
    count += 1