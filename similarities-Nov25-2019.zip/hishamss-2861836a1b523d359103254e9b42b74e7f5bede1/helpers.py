from nltk.tokenize import sent_tokenize


def lines(a, b):
    """Return lines in both a and b"""
    # TODO
    match = []
    alist = list(a.split('\n'))
    blist = list(b.split('\n'))

    for linea in alist:
        for lineb in blist:
            if lineb == linea:
                match.append(linea)
    res = []
    for x in match:
        if x not in res:
            res.append(x)

    return res


def sentences(a, b):
    """Return sentences in both a and b"""

    # TODO
    match = []
    alist = list(sent_tokenize(a))
    blist = list(sent_tokenize(b))

    for linea in alist:
        for lineb in blist:
            if lineb == linea:
                match.append(linea)
    res = []
    for x in match:
        if x not in res:
            res.append(x)
    return res


def substring_tokenize(str, n):
    substrings = []

    for i in range(len(str) - n + 1):
        substrings.append(str[i:i + n])

    return substrings


def substrings(a, b, n):
    """Return substrings of length n in both a and b"""

    # TODO
    match = set()
    a_substrings = set(substring_tokenize(a, n))
    b_substrings = set(substring_tokenize(b, n))
    #print (a_substrings)

    for linea in a_substrings:
        for lineb in b_substrings:
            if lineb == linea:
                match.add(linea)

    res = list()
    for x in match:
        if x not in res:
            res.append(x)
    return res

