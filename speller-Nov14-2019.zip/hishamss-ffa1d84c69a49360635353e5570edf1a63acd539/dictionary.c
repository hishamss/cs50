// Implements a dictionary's functionality

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dictionary.h"
#include <ctype.h>
// Represents number of children for each node in a trie
#define N 27

int loadcount = 0;

// Represents a node in a trie
typedef struct node
{
    bool is_word;
    struct node *children[N];
}
node;

void Delete(node *curr);
// Represents a trie
node *head;

node *GetNewNode()
{
// Initialize trie
    node *root = malloc(sizeof(node));

    if (root == NULL)
    {
        return root;
    }
    root->is_word = false;
    for (int i = 0; i < N; i++)
    {
        root->children[i] = NULL;
    }
    return root;
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    // Initialize trie
    head = GetNewNode();
    if (head == NULL)
    {
        return false;
    }

    // Open dictionary
    FILE *file = fopen(dictionary, "r");
    if (file == NULL)
    {
        unload();
        return false;
    }

    // Buffer for a word
    char word[LENGTH + 1];

    // Insert words into trie
    while (fscanf(file, "%s", word) != EOF)
    {
        // TODO
        node *trav = head;

        for (int level = 0; level < strlen(word); level++)
        {

            int index = word[level] - 'a';

            if (word[level] == '\'')
            {
                index = 26;
            }

            if (trav->children[index] == NULL)
            {
                trav->children[index] = GetNewNode();

            }

            trav = trav->children[index];

        }

        trav->is_word = true;

        // to count how many words we loaded from the dictionary
        loadcount++;

    }

    // Close dictionary
    fclose(file);

    // Indicate success
    return true;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    // TODO
    if (head == NULL)
    {
        return 0;
    }

    return loadcount;

}

// Returns true if word is in dictionary else false
bool check(const char *word)
{
    // TODO

    node *trav = head;

    for (int level = 0; level < strlen(word); level++)
    {


        int j = (tolower(word[level])) - 'a';

        if (word[level] == '\'')
        {
            j = 26;
        }

        trav = trav->children[j];

        if (trav == NULL)
        {
            return false;
        }
        // will return true if is_word is true and we reached the end of the word; which means the word from the tex
        // matches the word loaded from the dictionary.
        else if ((trav->is_word) && level == (strlen(word) - 1))
        {
            return true;
        }
    }

    return false;

}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    // TODO
    if (head == NULL)
    {

        return false;

    }

    Delete(head);
    return true;
}

void Delete(node *curr)
{

    for (int i = 0; i < N; i++)
    {
        if (curr->children[i] != NULL)
        {

            Delete(curr->children[i]);

        }

    }
    // free the current node of all the childs are null.
    free(curr);
    curr = NULL;
}
