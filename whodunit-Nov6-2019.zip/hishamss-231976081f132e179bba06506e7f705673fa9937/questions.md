# Questions

## What's `stdint.h`?

Microsoft's own implementations

## What's the point of using `uint8_t`, `uint32_t`, `int32_t`, and `uint16_t` in a program?

BITMAPFILEHEADER and BITMAPINFOHEADER make use of these types

## How many bytes is a `BYTE`, a `DWORD`, a `LONG`, and a `WORD`, respectively?

1 byte, 4 bytes, 4 bytes, 2 bytes

## What (in ASCII, decimal, or hexadecimal) must the first two bytes of any BMP file be? Leading bytes used to identify file formats (with high probability) are generally called "magic numbers."

BM, 16973, 0x424d

## What's the difference between `bfSize` and `biSize`?

bfSize: The size, in bytes, of the bitmap file.
biSize: The number of bytes required by the structure

## What does it mean if `biHeight` is negative?

the origin of bitmap is the upper-left corner.

## What field in `BITMAPINFOHEADER` specifies the BMP's color depth (i.e., bits per pixel)?

biBitCount

## Why might `fopen` return `NULL` in `copy.c`?

if the file trying to open does not exist or no permision to write or read.

## Why is the third argument to `fread` always `1` in our code?

1 means read one time BITMAPFILEHEADER and one time BITMAPINFOHEADER - there is only of these headers

## What value does `copy.c` assign to `padding` if `bi.biWidth` is `3`?

3

## What does `fseek` do?

skip padding

## What is `SEEK_CUR`?

file pointer’s current position
